/*
 * testDeck.java                                                    05/22
 */

package tests;

import carte.Deck;

public class testDeck {

    /** 
     * Lancement des m�thodes de tests de Deck avec v�rification des �checs
     * @param args non utilis�
     */
    public static void main(String[] args) {
        
        Deck deck = new Deck();
        
        System.out.println(deck);
        deck.supprimerCarte(0);
        System.out.println("\n" + deck);
    }
    
}
