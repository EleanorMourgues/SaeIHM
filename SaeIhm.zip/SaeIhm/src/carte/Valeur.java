/*
 * Valeur.java                                                    05/22
 */

package carte;

public enum Valeur {
	un, 
	deux, 
	trois, 
	quatre, 
	cinq
}
