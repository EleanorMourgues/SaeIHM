/*
 * Couleur.java                                                    05/22
 */

package carte;

public enum Couleur {
	rouge, 
	bleu, 
	rose, 
	vert, 
	blanc;
}
